﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.ComponentModel;

namespace JeuxDuPendu
{
    public enum NiveauDiff
    {
        [Description("Facile")]
        Facile,
        [Description("Moyen")]
        Moyen,
        [Description("Difficile")]
        Difficile


    }
   
}
